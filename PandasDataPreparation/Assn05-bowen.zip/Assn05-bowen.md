
# Assignment 5: Data Preparation

* Section: 01

* Name: Bryce Owen

* Due date:  March 25 2020

* Purpose:  Preparing data using standardization, categorization, binning, and outliers

## Working with the Data (Chapter 3)

#### 11. Derive an index field and add it to the dataset


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

bank_train = pd.read_csv("bank_marketing_training")
print(bank_train.shape)
bank_train['index'] = pd.Series(range(0,26874))
bank_train.head()
```

    (26874, 21)





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>job</th>
      <th>marital</th>
      <th>education</th>
      <th>default</th>
      <th>housing</th>
      <th>loan</th>
      <th>contact</th>
      <th>month</th>
      <th>day_of_week</th>
      <th>...</th>
      <th>days_since_previous</th>
      <th>previous</th>
      <th>previous_outcome</th>
      <th>emp.var.rate</th>
      <th>cons.price.idx</th>
      <th>cons.conf.idx</th>
      <th>euribor3m</th>
      <th>nr.employed</th>
      <th>response</th>
      <th>index</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>56</td>
      <td>housemaid</td>
      <td>married</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>57</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>unknown</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>41</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>unknown</td>
      <td>unknown</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>25</td>
      <td>services</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>29</td>
      <td>blue-collar</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>999</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 22 columns</p>
</div>



#### 12. For the *days_since_previous* field, change the field value 999 to the appropriate code for missing values


```python
import numpy as np
bank_train['days_since_previous'] = bank_train['days_since_previous'].replace({999:np.NaN})
bank_train.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>job</th>
      <th>marital</th>
      <th>education</th>
      <th>default</th>
      <th>housing</th>
      <th>loan</th>
      <th>contact</th>
      <th>month</th>
      <th>day_of_week</th>
      <th>...</th>
      <th>days_since_previous</th>
      <th>previous</th>
      <th>previous_outcome</th>
      <th>emp.var.rate</th>
      <th>cons.price.idx</th>
      <th>cons.conf.idx</th>
      <th>euribor3m</th>
      <th>nr.employed</th>
      <th>response</th>
      <th>index</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>56</td>
      <td>housemaid</td>
      <td>married</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>NaN</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>57</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>unknown</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>NaN</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>41</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>unknown</td>
      <td>unknown</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>NaN</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>25</td>
      <td>services</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>NaN</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>29</td>
      <td>blue-collar</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>NaN</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 22 columns</p>
</div>



#### 13. For the *education* field, reexpress the field values as the numeric values shown in table 3.1


```python
bank_train['education_numeric'] = bank_train['education']
dict_edu = {'education_numeric': {'illiterate': 0, 'basic.4y': 4, 'basic.6y': 6, 'basic.9y': 9, 'high.school': 12, 'professional.course': 12, 'university.degree': 16, 'unknown': np.NaN}}
bank_train.replace(dict_edu, inplace = True)
bank_train.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>job</th>
      <th>marital</th>
      <th>education</th>
      <th>default</th>
      <th>housing</th>
      <th>loan</th>
      <th>contact</th>
      <th>month</th>
      <th>day_of_week</th>
      <th>...</th>
      <th>previous</th>
      <th>previous_outcome</th>
      <th>emp.var.rate</th>
      <th>cons.price.idx</th>
      <th>cons.conf.idx</th>
      <th>euribor3m</th>
      <th>nr.employed</th>
      <th>response</th>
      <th>index</th>
      <th>education_numeric</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>56</td>
      <td>housemaid</td>
      <td>married</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>57</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>unknown</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>1</td>
      <td>12.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>41</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>unknown</td>
      <td>unknown</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>2</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>25</td>
      <td>services</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>3</td>
      <td>12.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>29</td>
      <td>blue-collar</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>4</td>
      <td>12.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 23 columns</p>
</div>



#### 14. Standardize the field *age*. Print out a list of the first 10 records, including the variables *age* and *age_z*


```python
from scipy import stats

bank_train['age_z'] = stats.zscore(bank_train['age'])
bank_train.head(10)[['age','age_z']]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>age_z</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>56</td>
      <td>1.539625</td>
    </tr>
    <tr>
      <th>1</th>
      <td>57</td>
      <td>1.635778</td>
    </tr>
    <tr>
      <th>2</th>
      <td>41</td>
      <td>0.097330</td>
    </tr>
    <tr>
      <th>3</th>
      <td>25</td>
      <td>-1.441118</td>
    </tr>
    <tr>
      <th>4</th>
      <td>29</td>
      <td>-1.056506</td>
    </tr>
    <tr>
      <th>5</th>
      <td>57</td>
      <td>1.635778</td>
    </tr>
    <tr>
      <th>6</th>
      <td>35</td>
      <td>-0.479588</td>
    </tr>
    <tr>
      <th>7</th>
      <td>39</td>
      <td>-0.094976</td>
    </tr>
    <tr>
      <th>8</th>
      <td>30</td>
      <td>-0.960353</td>
    </tr>
    <tr>
      <th>9</th>
      <td>55</td>
      <td>1.443472</td>
    </tr>
  </tbody>
</table>
</div>



#### 15. Obtain a listing of all records that are outliers according to the field *age_z*. Print out a listing of the 10 largest *age_z* values


```python
bank_train.query('age_z > 3 | age_z < -3')
bank_train_outliers = bank_train.query('age_z > 3 | age_z < -3')
bank_train_sort = bank_train_outliers.sort_values(['age_z'], ascending = False)
bank_train_sort.head(10)[['age_z']]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age_z</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>24840</th>
      <td>4.904980</td>
    </tr>
    <tr>
      <th>24833</th>
      <td>4.904980</td>
    </tr>
    <tr>
      <th>26520</th>
      <td>4.712674</td>
    </tr>
    <tr>
      <th>26015</th>
      <td>4.712674</td>
    </tr>
    <tr>
      <th>23628</th>
      <td>4.616521</td>
    </tr>
    <tr>
      <th>25098</th>
      <td>4.616521</td>
    </tr>
    <tr>
      <th>26516</th>
      <td>4.616521</td>
    </tr>
    <tr>
      <th>26509</th>
      <td>4.616521</td>
    </tr>
    <tr>
      <th>18179</th>
      <td>4.616521</td>
    </tr>
    <tr>
      <th>18191</th>
      <td>4.616521</td>
    </tr>
  </tbody>
</table>
</div>



#### 16. For the *job* field, combine the jobs with less than 5% of the records into a field called *other*


```python
# UNSURE HOW TO COMPLETE 

job_count = (bank_train.groupby('job').count()['index']/bank_train.shape[0]) * 100
job_count = job_count.to_frame()
job_count[job_count['index'] < 5]

dict_job = {"job": {"entrepreneur": "other", "housemaid": "other", "retired": "other", "self-employed": "other", "student": "other", "unemployed": "other", "unknown": "other"}}
bank_train.replace(dict_job, inplace = True)
bank_train.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>job</th>
      <th>marital</th>
      <th>education</th>
      <th>default</th>
      <th>housing</th>
      <th>loan</th>
      <th>contact</th>
      <th>month</th>
      <th>day_of_week</th>
      <th>...</th>
      <th>previous</th>
      <th>previous_outcome</th>
      <th>emp.var.rate</th>
      <th>cons.price.idx</th>
      <th>cons.conf.idx</th>
      <th>euribor3m</th>
      <th>nr.employed</th>
      <th>response</th>
      <th>index</th>
      <th>age_z</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>56</td>
      <td>other</td>
      <td>married</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>0</td>
      <td>1.539625</td>
    </tr>
    <tr>
      <th>1</th>
      <td>57</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>unknown</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>1</td>
      <td>1.635778</td>
    </tr>
    <tr>
      <th>2</th>
      <td>41</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>unknown</td>
      <td>unknown</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>2</td>
      <td>0.097330</td>
    </tr>
    <tr>
      <th>3</th>
      <td>25</td>
      <td>services</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>3</td>
      <td>-1.441118</td>
    </tr>
    <tr>
      <th>4</th>
      <td>29</td>
      <td>blue-collar</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>0</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>4</td>
      <td>-1.056506</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 23 columns</p>
</div>



#### 17. Rename the *default* predictor to *credit_default*


```python
bank_train = bank_train.rename(columns={'default': 'credit_default'})
bank_train.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>job</th>
      <th>marital</th>
      <th>education</th>
      <th>credit_default</th>
      <th>housing</th>
      <th>loan</th>
      <th>contact</th>
      <th>month</th>
      <th>day_of_week</th>
      <th>...</th>
      <th>previous_outcome</th>
      <th>emp.var.rate</th>
      <th>cons.price.idx</th>
      <th>cons.conf.idx</th>
      <th>euribor3m</th>
      <th>nr.employed</th>
      <th>response</th>
      <th>index</th>
      <th>education_numeric</th>
      <th>age_z</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>56</td>
      <td>housemaid</td>
      <td>married</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>0</td>
      <td>4.0</td>
      <td>1.539625</td>
    </tr>
    <tr>
      <th>1</th>
      <td>57</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>unknown</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>1</td>
      <td>12.0</td>
      <td>1.635778</td>
    </tr>
    <tr>
      <th>2</th>
      <td>41</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>unknown</td>
      <td>unknown</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>2</td>
      <td>NaN</td>
      <td>0.097330</td>
    </tr>
    <tr>
      <th>3</th>
      <td>25</td>
      <td>services</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>3</td>
      <td>12.0</td>
      <td>-1.441118</td>
    </tr>
    <tr>
      <th>4</th>
      <td>29</td>
      <td>blue-collar</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>4</td>
      <td>12.0</td>
      <td>-1.056506</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 24 columns</p>
</div>



#### 18. For the variable *month*, change the field values to 1-12, but keep the variable as categorical


```python
bank_train['month'] = bank_train['month'].replace({'jan':'1', 'feb':'2','mar':'3','apr':'4','may':'5','jun':'6','jul':'7','aug':'8','sep':'9','oct':'10','nov':'11','dec':'12',})
bank_train.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>job</th>
      <th>marital</th>
      <th>education</th>
      <th>credit_default</th>
      <th>housing</th>
      <th>loan</th>
      <th>contact</th>
      <th>month</th>
      <th>day_of_week</th>
      <th>...</th>
      <th>previous_outcome</th>
      <th>emp.var.rate</th>
      <th>cons.price.idx</th>
      <th>cons.conf.idx</th>
      <th>euribor3m</th>
      <th>nr.employed</th>
      <th>response</th>
      <th>index</th>
      <th>education_numeric</th>
      <th>age_z</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>56</td>
      <td>housemaid</td>
      <td>married</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>5</td>
      <td>mon</td>
      <td>...</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>0</td>
      <td>4.0</td>
      <td>1.539625</td>
    </tr>
    <tr>
      <th>1</th>
      <td>57</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>unknown</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>5</td>
      <td>mon</td>
      <td>...</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>1</td>
      <td>12.0</td>
      <td>1.635778</td>
    </tr>
    <tr>
      <th>2</th>
      <td>41</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>unknown</td>
      <td>unknown</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>5</td>
      <td>mon</td>
      <td>...</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>2</td>
      <td>NaN</td>
      <td>0.097330</td>
    </tr>
    <tr>
      <th>3</th>
      <td>25</td>
      <td>services</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>5</td>
      <td>mon</td>
      <td>...</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>3</td>
      <td>12.0</td>
      <td>-1.441118</td>
    </tr>
    <tr>
      <th>4</th>
      <td>29</td>
      <td>blue-collar</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>telephone</td>
      <td>5</td>
      <td>mon</td>
      <td>...</td>
      <td>nonexistent</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191</td>
      <td>no</td>
      <td>4</td>
      <td>12.0</td>
      <td>-1.056506</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 24 columns</p>
</div>



#### 19. Do the following for the *duration* field

   ##### a). Standardize the variable
    
   ##### b). Identify how many outliers there are and identify the most extreme outlier


```python
bank_train['duration_z'] = stats.zscore(bank_train['duration'])

bank_train.query('duration_z > 3 | duration_z < -3')
bank_train_duration_outliers = bank_train.query('duration_z > 3 | duration_z < -3')
bank_train_duration_sort = bank_train_duration_outliers.sort_values(['duration_z'], ascending = False)
print('Number of outliers:', bank_train_duration_outliers.shape[0])
print('Most extreme outlier: ')
bank_train_duration_sort.head(1)[['duration_z']]
```

    Number of outliers: 549
    Most extreme outlier: 





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>duration_z</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>15764</th>
      <td>17.995198</td>
    </tr>
  </tbody>
</table>
</div>



#### 20. Do the following for the *campaign* field

   ##### a). Standardize the variable
    
   ##### b). Identify how many outliers there are and identify the most extreme outlier


```python
bank_train['campaign_z'] = stats.zscore(bank_train['campaign'])

bank_train.query('campaign_z > 3 | campaign_z < -3')
bank_train_campaign_outliers = bank_train.query('campaign_z > 3 | campaign_z < -3')
bank_train_campaign_sort = bank_train_campaign_outliers.sort_values(['campaign_z'], ascending = False)
print('Number of outliers:', bank_train_campaign_outliers.shape[0])
print('Most extreme outlier: ')
bank_train_campaign_sort.head(1)[['campaign_z']]
```

    Number of outliers: 548
    Most extreme outlier: 





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>campaign_z</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>12257</th>
      <td>14.711334</td>
    </tr>
  </tbody>
</table>
</div>



## Working with the Data (Chapter 4)

#### 15. Create a bar graph of the *previous_outcome* variable, with *response* overlay


```python
crosstab_01 = pd.crosstab(bank_train['previous_outcome'], bank_train['response'])
crosstab_01.plot(kind = 'bar', stacked = True)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1a1b0e6860>




![png](output_25_1.png)


#### 16. Create a normalized bar graph of *previous_outcome* variable with *response* overlay. Describe the relationship between *previous_outcome* and *response*


```python
crosstab_normal = crosstab_01.div(crosstab_01.sum(1), axis = 0)
crosstab_normal.plot(kind = 'bar', stacked = True)
# If the previous outcome was a success, then the respondant was more likely to respond. The inverse is also true.
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1a1b17fd68>




![png](output_27_1.png)


#### 17. Create a contingency table of *previous_outcome* and *response*. Compare the contingency table with the non‐normalized bar graph and the normalized bar graph


```python
crosstab_02 = pd.crosstab(bank_train['response'], bank_train['previous_outcome'])
round(crosstab_02.div(crosstab_02.sum(0), axis = 1)*100, 1)
#The contingency tabe and the normalized bar graph both look at response rates for each previous outcome and are the same values
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>previous_outcome</th>
      <th>failure</th>
      <th>nonexistent</th>
      <th>success</th>
    </tr>
    <tr>
      <th>response</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>no</th>
      <td>86.1</td>
      <td>91.2</td>
      <td>36.0</td>
    </tr>
    <tr>
      <th>yes</th>
      <td>13.9</td>
      <td>8.8</td>
      <td>64.0</td>
    </tr>
  </tbody>
</table>
</div>



#### 18. Create a histogram of *age* with *response* overlay


```python
bank_train_age_yes = bank_train[bank_train.response == "yes"]['age']
bank_train_age_no = bank_train[bank_train.response == "no"]['age']
plt.hist([bank_train_age_yes, bank_train_age_no], bins = 10, stacked = True)
plt.legend(['Response = Yes', 'Response = No'])
plt.title('Histogram of Age with Response Overlay')
plt.xlabel('Age');
plt.ylabel('Frequency');
plt.show()
```


![png](output_31_0.png)


#### 19. Create a normalized histogram of *age* with *response* overlay. Describe the relationship between *age* and *response*


```python

n_table = np.column_stack((n[0], n[1]))
n_norm = n_table / n_table.sum(axis=1)[:, None]
ourbins = np.column_stack((bins[0:10], bins[1:11]))
p1 = plt.bar(x = ourbins[:,0], height = n_norm[:,0], width = ourbins[:, 1] - ourbins[:, 0])
p2 = plt.bar(x = ourbins[:,0], height = n_norm[:,1], width = ourbins[:, 1] - ourbins[:, 0], bottom = n_norm[:,0])
plt.legend(['Response = Yes', 'Response = No'])
plt.title('Normalized Histogram of Age with Response Overlay')
plt.xlabel('Age'); plt.ylabel('Proportion'); plt.show()
# The overall number of responses was highest among the 30-60 age range, but the highest percentage of responses came form the 60-80 age group
```


![png](output_33_0.png)


#### 20. Bin the *age* variable using the bins specified in this chapter and create a bar chart of the binned *age* variable with *response* overlay


```python
bank_train['age_binned'] = pd.cut(x = bank_train['age'], bins = [0, 27, 60.01, 100], labels=["Under 27", "27 to 60", "Over 60"], right = False)
crosstab_02 = pd.crosstab(bank_train['age_binned'], bank_train['response'])
crosstab_02.plot(kind='bar', stacked = True, title = 'Binned Bar Graph of Age with Response Overlay')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1a1cd31f98>




![png](output_35_1.png)


#### 21. "Produce the following graphs. What is the strength of each graph? Weakness?
   ##### a. Bar graph of marital
   ##### b. Bar graph of marital, with overlay of response
   ##### c. Normalized bar graph of marital, with overlay of response


```python
# A. Strength: shows the total number of people in each marital category. Weakness: Has no response data.
bank_train.groupby('marital')['index'].nunique().plot(kind='bar')
# B. Strength: shows the total number of people in each marital category plus responses vs non responses. Weakness: Does not show the response rate as a percentage of the group.
crosstab_01 = pd.crosstab(bank_train['marital'], bank_train['response'])
crosstab_01.plot(kind = 'bar', stacked = True)
# C. Strength: shows the percentage of each group that responded. Weakness: Does not show total amounts of responses in each group.
crosstab_normal = crosstab_01.div(crosstab_01.sum(1), axis = 0)
crosstab_normal.plot(kind = 'bar', stacked = True)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1a1d241908>




![png](output_37_1.png)



![png](output_37_2.png)



![png](output_37_3.png)


#### 22. Use the graph from exercise 21c, describe the relationship between *marital* and *response*


```python
# There really is not any statistical difference between the response rates from different marital groups (~ 10% each)
```

#### 23. Do the following with the variables *marital* and *response*
   ##### a. Build a contingency table, being careful to have the correct variables representing the rows and columns. Report the counts and the column percentages
   ##### b. Describe what the contingency table is telling you


```python
crosstab_03 = pd.crosstab(bank_train['response'], bank_train['marital'])
print('Crosstab counts:')
print(crosstab_03)
print('Crosstab percentages: ')
print(round(crosstab_03.div(crosstab_03.sum(0), axis = 1)*100, 1))
# B. The contingency tables are giving us the counted responses and counted response rate respectively for each marital status
```

    Crosstab counts:
    marital   divorced  married  single  unknown
    response                                    
    no            2743    14579    6514       50
    yes            312     1608    1061        7
    Crosstab percentages: 
    marital   divorced  married  single  unknown
    response                                    
    no            89.8     90.1    86.0     87.7
    yes           10.2      9.9    14.0     12.3

